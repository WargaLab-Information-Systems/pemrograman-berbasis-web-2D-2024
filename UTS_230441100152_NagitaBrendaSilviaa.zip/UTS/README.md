# Format pengumpulan

## Format penamaan folder

Buatlah folder nim-nama di dalam folder UTS ini, sesuai dengan format berikut.

Format nama folder
-- NIM-Nama

Contoh penamaan folder
-- 220441100016-M.SyaifulAnam

## Format penamaan file

Penamaan file sesuai dengan yang diinginkan.
